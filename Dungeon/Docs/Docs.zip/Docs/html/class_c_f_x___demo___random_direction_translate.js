var class_c_f_x___demo___random_direction_translate =
[
    [ "axis", "class_c_f_x___demo___random_direction_translate.html#a915b742f044a094751704a7ccb999c28", null ],
    [ "baseDir", "class_c_f_x___demo___random_direction_translate.html#af56af88cf807c78ada607f693064e80c", null ],
    [ "gravity", "class_c_f_x___demo___random_direction_translate.html#aca5a3f2bc13a5226973ba2121681f7de", null ],
    [ "speed", "class_c_f_x___demo___random_direction_translate.html#a9dca9953165b79b2531c7e18b3a8a52a", null ]
];