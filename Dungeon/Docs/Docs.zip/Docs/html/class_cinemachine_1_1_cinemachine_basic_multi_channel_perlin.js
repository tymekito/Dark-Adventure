var class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin =
[
    [ "MutateCameraState", "class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin.html#a1c6704ef9ef421de60d16e8caf6d4e88", null ],
    [ "m_AmplitudeGain", "class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin.html#ae3c9d571b1e1362bbe934afb61cee71b", null ],
    [ "m_FrequencyGain", "class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin.html#a6842154ed1460698f6b197ee9657e3e4", null ],
    [ "m_NoiseProfile", "class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin.html#a48275e7475249a683366cd3e723d0839", null ],
    [ "IsValid", "class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin.html#adbb87a1d6fe6e9b9d68fe02018ccdf1f", null ],
    [ "Stage", "class_cinemachine_1_1_cinemachine_basic_multi_channel_perlin.html#a0121a22c92ff674717d7cb9b22f6e6de", null ]
];