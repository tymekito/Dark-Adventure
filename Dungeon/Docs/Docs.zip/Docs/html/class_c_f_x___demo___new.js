var class_c_f_x___demo___new =
[
    [ "OnNextEffect", "class_c_f_x___demo___new.html#a774094fcd1c93f1d78c63c3103338690", null ],
    [ "OnPreviousEffect", "class_c_f_x___demo___new.html#a2c8baa5d8343c97dac9a99a2035e8f97", null ],
    [ "OnToggleCamera", "class_c_f_x___demo___new.html#adfa85015d1a9ed58a1411333e771b88f", null ],
    [ "OnToggleGround", "class_c_f_x___demo___new.html#a33d9df366d1053f721fabdb28dc954ab", null ],
    [ "OnToggleSlowMo", "class_c_f_x___demo___new.html#aa80b5de4ae009fdbac93ea63f860cc8d", null ],
    [ "camRotBtn", "class_c_f_x___demo___new.html#a09564fe450a193520178919b8bb78bf2", null ],
    [ "camRotLabel", "class_c_f_x___demo___new.html#a0e07f36f4215df834b31e9b2de061820", null ],
    [ "EffectIndexLabel", "class_c_f_x___demo___new.html#a8c0b6e1c8a2235a50e65648dac987b4e", null ],
    [ "EffectLabel", "class_c_f_x___demo___new.html#a6d3eeb363fc62d2150c829e277b555cd", null ],
    [ "groundBtn", "class_c_f_x___demo___new.html#ad2c18ad8dbd9f7fd4c974f7702a3bd7a", null ],
    [ "groundCollider", "class_c_f_x___demo___new.html#a804f19c390e3d603de07adce1303264a", null ],
    [ "groundLabel", "class_c_f_x___demo___new.html#a3071bd6c0fb58e1817e14549471c025c", null ],
    [ "groundRenderer", "class_c_f_x___demo___new.html#ab8254550fd6447b923324bd1b33e28a9", null ],
    [ "slowMoBtn", "class_c_f_x___demo___new.html#aadea0cc894d8d55d2efacd9cfc6b60db", null ],
    [ "slowMoLabel", "class_c_f_x___demo___new.html#a372b86cdda7f99a17e3bc9e648161298", null ]
];