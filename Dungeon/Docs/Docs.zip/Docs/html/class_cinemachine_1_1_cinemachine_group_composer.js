var class_cinemachine_1_1_cinemachine_group_composer =
[
    [ "AdjustmentMode", "class_cinemachine_1_1_cinemachine_group_composer.html#a8568c2b4b862a1e9e7f22f4f58b28c20", [
      [ "ZoomOnly", "class_cinemachine_1_1_cinemachine_group_composer.html#a8568c2b4b862a1e9e7f22f4f58b28c20a5596e681c19076a4a5ecceb43a55abc4", null ],
      [ "DollyOnly", "class_cinemachine_1_1_cinemachine_group_composer.html#a8568c2b4b862a1e9e7f22f4f58b28c20a9d7434ac39965e2da13733ea20ff25e8", null ],
      [ "DollyThenZoom", "class_cinemachine_1_1_cinemachine_group_composer.html#a8568c2b4b862a1e9e7f22f4f58b28c20adc96c9f9a562fee4d252d46b4266dd02", null ]
    ] ],
    [ "FramingMode", "class_cinemachine_1_1_cinemachine_group_composer.html#a4034aad90abb8378a14caf983a7c3545", [
      [ "Horizontal", "class_cinemachine_1_1_cinemachine_group_composer.html#a4034aad90abb8378a14caf983a7c3545ac1b5fa03ecdb95d4a45dd1c40b02527f", null ],
      [ "Vertical", "class_cinemachine_1_1_cinemachine_group_composer.html#a4034aad90abb8378a14caf983a7c3545a06ce2a25e5d12c166a36f654dbea6012", null ],
      [ "HorizontalAndVertical", "class_cinemachine_1_1_cinemachine_group_composer.html#a4034aad90abb8378a14caf983a7c3545a8a4ec9cfaa0a4f67a270b8741f45184b", null ]
    ] ],
    [ "MutateCameraState", "class_cinemachine_1_1_cinemachine_group_composer.html#a9f1b75a63cb9d96fa12f997fa2496ccd", null ],
    [ "m_AdjustmentMode", "class_cinemachine_1_1_cinemachine_group_composer.html#a1b4a7384b3b234e8276bbec866f28e62", null ],
    [ "m_FrameDamping", "class_cinemachine_1_1_cinemachine_group_composer.html#a455027a9ab1882acde15485e2355f92f", null ],
    [ "m_FramingMode", "class_cinemachine_1_1_cinemachine_group_composer.html#a95e3dc46fc2b587a2f07777b57d4abdc", null ],
    [ "m_GroupFramingSize", "class_cinemachine_1_1_cinemachine_group_composer.html#ae67c576d71c3903225babd14a11fd231", null ],
    [ "m_MaxDollyIn", "class_cinemachine_1_1_cinemachine_group_composer.html#ad429a6585a569868dc32fc515c7b3619", null ],
    [ "m_MaxDollyOut", "class_cinemachine_1_1_cinemachine_group_composer.html#ac609aa17f7c6a0ca374ab162ae06bc73", null ],
    [ "m_MaximumDistance", "class_cinemachine_1_1_cinemachine_group_composer.html#a28e8332db5b35f5baefd7ec6a6c1504d", null ],
    [ "m_MaximumFOV", "class_cinemachine_1_1_cinemachine_group_composer.html#a48137706119529ff1e5ae7511003dba9", null ],
    [ "m_MaximumOrthoSize", "class_cinemachine_1_1_cinemachine_group_composer.html#ab285f8dc45dfed35b696bd2bba6feb45", null ],
    [ "m_MinimumDistance", "class_cinemachine_1_1_cinemachine_group_composer.html#a9f30631678dfeed93a895a62919dc2ef", null ],
    [ "m_MinimumFOV", "class_cinemachine_1_1_cinemachine_group_composer.html#a81d812664a12ba2e7b3b1679e3a58509", null ],
    [ "m_MinimumOrthoSize", "class_cinemachine_1_1_cinemachine_group_composer.html#acb981bc4896bf18e79481dd126cf4b95", null ],
    [ "m_LastBounds", "class_cinemachine_1_1_cinemachine_group_composer.html#ad24a15a43ae1fd3f6ef22a7057b341d4", null ],
    [ "m_lastBoundsMatrix", "class_cinemachine_1_1_cinemachine_group_composer.html#aee1d8169f91dba1b2deda830750ee340", null ],
    [ "TargetGroup", "class_cinemachine_1_1_cinemachine_group_composer.html#a03344b14d1a25adaa3d003745c632c75", null ]
];