var class_room_template =
[
    [ "boss", "class_room_template.html#a8c24643134b1dbbb77e146f83536357f", null ],
    [ "bossRooms", "class_room_template.html#a909069025674dd9fff651a2b546cec0e", null ],
    [ "bottomRooms", "class_room_template.html#ad3379a67b5bde49806de63642861d059", null ],
    [ "closeRooms", "class_room_template.html#af0a60fc4225d6310e719c1f43c21ab93", null ],
    [ "leftRooms", "class_room_template.html#a02228f23ed316fd50929e1db56c751eb", null ],
    [ "rightRooms", "class_room_template.html#ada94769cfff5c31d0a07f19947cfabd2", null ],
    [ "rooms", "class_room_template.html#a1f673bbf88291848a7d0b8b771150511", null ],
    [ "topRooms", "class_room_template.html#a55ed5b35e5a411fa9a44e1dea7d7e192", null ],
    [ "waitTime", "class_room_template.html#a0c1c62394f5c0e3f87dd0d57e08c7099", null ]
];