var class_cinemachine_1_1_cinemachine_extension =
[
    [ "Awake", "class_cinemachine_1_1_cinemachine_extension.html#a6baac99917da49475093b3f26c453bb0", null ],
    [ "GetAllExtraStates< T >", "class_cinemachine_1_1_cinemachine_extension.html#af74bc5bc0736aa840a0ac7783bea7aef", null ],
    [ "GetExtraState< T >", "class_cinemachine_1_1_cinemachine_extension.html#abfd25e075e45a038b59e17ac7b55dc02", null ],
    [ "OnDestroy", "class_cinemachine_1_1_cinemachine_extension.html#adf1df72db4c68b49f91c2685470b80ef", null ],
    [ "PostPipelineStageCallback", "class_cinemachine_1_1_cinemachine_extension.html#aec1360a648d0cf34acddf0863aa30e75", null ],
    [ "Epsilon", "class_cinemachine_1_1_cinemachine_extension.html#aa0b467eb6f3362ec44107ee8972a23c2", null ],
    [ "VirtualCamera", "class_cinemachine_1_1_cinemachine_extension.html#a60701cdc32472ae8a9f544340e986abb", null ]
];