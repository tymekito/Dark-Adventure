var class_colsing_credits_controller =
[
    [ "scoreText", "class_colsing_credits_controller.html#a42e4eb348c9101e3f13996d2e12d83c0", null ]
];