var class_cinemachine_1_1_cinemachine_collider =
[
    [ "ResolutionStrategy", "class_cinemachine_1_1_cinemachine_collider.html#a78d26832f600bda07e02dabbddec0f60", [
      [ "PullCameraForward", "class_cinemachine_1_1_cinemachine_collider.html#a78d26832f600bda07e02dabbddec0f60a6aaf8ec885b37e23891d7730eb2668a4", null ],
      [ "PreserveCameraHeight", "class_cinemachine_1_1_cinemachine_collider.html#a78d26832f600bda07e02dabbddec0f60a03f5f452ebe44be076680de06dbf0403", null ],
      [ "PreserveCameraDistance", "class_cinemachine_1_1_cinemachine_collider.html#a78d26832f600bda07e02dabbddec0f60a2b0cdfc5e056466608a9a9cbef3c700e", null ]
    ] ],
    [ "CameraWasDisplaced", "class_cinemachine_1_1_cinemachine_collider.html#a36c62104896ab3dcffdbc0c3f1febe5b", null ],
    [ "IsTargetObscured", "class_cinemachine_1_1_cinemachine_collider.html#ad0e0a483443327eca3acd9664e00fb06", null ],
    [ "OnDestroy", "class_cinemachine_1_1_cinemachine_collider.html#a20834c8d962e19cab8338e1ed85d4f1a", null ],
    [ "PostPipelineStageCallback", "class_cinemachine_1_1_cinemachine_collider.html#a99511e7dac987c22319e0781eaff968c", null ],
    [ "m_AvoidObstacles", "class_cinemachine_1_1_cinemachine_collider.html#a3e552f25541c6c55c2834513e14e9efb", null ],
    [ "m_CameraRadius", "class_cinemachine_1_1_cinemachine_collider.html#aaddbe892573f07238c3448c1d036077b", null ],
    [ "m_CollideAgainst", "class_cinemachine_1_1_cinemachine_collider.html#abdf92ae660238b6a56e964011dac9bd1", null ],
    [ "m_Damping", "class_cinemachine_1_1_cinemachine_collider.html#a239632a4e2c0a444a3e7b946df648beb", null ],
    [ "m_DistanceLimit", "class_cinemachine_1_1_cinemachine_collider.html#ae63cfa838c439092b0e645a0967ed644", null ],
    [ "m_IgnoreTag", "class_cinemachine_1_1_cinemachine_collider.html#ad0918cca1f2faf7a8eb141016110ba86", null ],
    [ "m_MaximumEffort", "class_cinemachine_1_1_cinemachine_collider.html#a1d5bc3cd71b34abdac3bc3a2b47b9d91", null ],
    [ "m_MinimumDistanceFromTarget", "class_cinemachine_1_1_cinemachine_collider.html#a6a8dbdcc7959e73e58ac246135906aae", null ],
    [ "m_OptimalTargetDistance", "class_cinemachine_1_1_cinemachine_collider.html#a0900e918e20b5e9bfd9a06f01a4f355c", null ],
    [ "m_Strategy", "class_cinemachine_1_1_cinemachine_collider.html#a9e59b9e9e3c45eba984e32454f2bd282", null ],
    [ "DebugPaths", "class_cinemachine_1_1_cinemachine_collider.html#af6d4608b13a3880db0e306fa5ab4d510", null ]
];