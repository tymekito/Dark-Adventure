var class_cinemachine_1_1_editor_1_1_cinemachine_menu =
[
    [ "CreateCameraBrainIfAbsent", "class_cinemachine_1_1_editor_1_1_cinemachine_menu.html#a6c8222b6298c6a2d5b07acab78de4ff1", null ],
    [ "CreateDefaultVirtualCamera", "class_cinemachine_1_1_editor_1_1_cinemachine_menu.html#a54df89e5b2e19678dc7b5e6991f9e38c", null ],
    [ "CreateVirtualCamera", "class_cinemachine_1_1_editor_1_1_cinemachine_menu.html#a101bf66e256c8b8334daca15d82962ff", null ],
    [ "GenerateUniqueObjectName", "class_cinemachine_1_1_editor_1_1_cinemachine_menu.html#a698c4968beae80e3ab936c1600d1dc15", null ],
    [ "kCinemachineRootMenu", "class_cinemachine_1_1_editor_1_1_cinemachine_menu.html#abffc63887cf2ff2bc4a27860b0465834", null ]
];