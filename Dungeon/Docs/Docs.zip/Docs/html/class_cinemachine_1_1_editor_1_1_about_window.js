var class_cinemachine_1_1_editor_1_1_about_window =
[
    [ "LastVersionLoaded", "class_cinemachine_1_1_editor_1_1_about_window.html#a7827efc9c1383e06e6506e680e539446", null ]
];