var dir_441480ef845a770e33a339456493552a =
[
    [ "CFX_AutoDestructShuriken.cs", "_c_f_x___auto_destruct_shuriken_8cs.html", [
      [ "CFX_AutoDestructShuriken", "class_c_f_x___auto_destruct_shuriken.html", "class_c_f_x___auto_destruct_shuriken" ]
    ] ],
    [ "CFX_AutoRotate.cs", "_c_f_x___auto_rotate_8cs.html", [
      [ "CFX_AutoRotate", "class_c_f_x___auto_rotate.html", "class_c_f_x___auto_rotate" ]
    ] ],
    [ "CFX_LightFlicker.cs", "_c_f_x___light_flicker_8cs.html", [
      [ "CFX_LightFlicker", "class_c_f_x___light_flicker.html", "class_c_f_x___light_flicker" ]
    ] ],
    [ "CFX_LightIntensityFade.cs", "_c_f_x___light_intensity_fade_8cs.html", [
      [ "CFX_LightIntensityFade", "class_c_f_x___light_intensity_fade.html", "class_c_f_x___light_intensity_fade" ]
    ] ]
];