var class_cinemachine_1_1_cinemachine_same_as_follow_object =
[
    [ "MutateCameraState", "class_cinemachine_1_1_cinemachine_same_as_follow_object.html#a8a922e8805a54b172a09b15901ae17a3", null ],
    [ "IsValid", "class_cinemachine_1_1_cinemachine_same_as_follow_object.html#a8ec07cac40119378d4fae625d111cefa", null ],
    [ "Stage", "class_cinemachine_1_1_cinemachine_same_as_follow_object.html#acf6e66837ea6f62eefd9f86fe510443e", null ]
];