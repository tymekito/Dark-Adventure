var class_cinemachine_1_1_cinemachine_follow_zoom =
[
    [ "PostPipelineStageCallback", "class_cinemachine_1_1_cinemachine_follow_zoom.html#a8205a7dd2c4bf4d3f148f78383bbcd32", null ],
    [ "m_Damping", "class_cinemachine_1_1_cinemachine_follow_zoom.html#a46138764be8c6fb58fda8c26bbcfec79", null ],
    [ "m_MaxFOV", "class_cinemachine_1_1_cinemachine_follow_zoom.html#a3c4ca255c3f3b25eae192776f0357f4a", null ],
    [ "m_MinFOV", "class_cinemachine_1_1_cinemachine_follow_zoom.html#aa69f055aea73542333e54936b91fa523", null ],
    [ "m_Width", "class_cinemachine_1_1_cinemachine_follow_zoom.html#a1af1fad0f02b48382148c7153fd10e10", null ]
];