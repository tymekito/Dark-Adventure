var class_cinemachine_1_1_cinemachine_transposer =
[
    [ "BindingMode", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0b", [
      [ "LockToTargetOnAssign", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0bacbd7246786dfeab807738745c14d0d94", null ],
      [ "LockToTargetWithWorldUp", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0baa1c4a85bb5af449a9337c20ec293e621", null ],
      [ "LockToTargetNoRoll", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0ba0e11225a17b822ffc26f09ea91f5a6cf", null ],
      [ "LockToTarget", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0baaaac3cb806ad0f4737620ee349f546d5", null ],
      [ "WorldSpace", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0ba43c5bd4a88c440bd0862f954e4faa177", null ],
      [ "SimpleFollowWithWorldUp", "class_cinemachine_1_1_cinemachine_transposer.html#ac2ed72c89186c06f0d7972e3ad65ab0baf9d58f0af525093acc8783eca8cd2330", null ]
    ] ],
    [ "GeTargetCameraPosition", "class_cinemachine_1_1_cinemachine_transposer.html#a4cee93c83702f4d58cdaeca1d3aee2ec", null ],
    [ "GetReferenceOrientation", "class_cinemachine_1_1_cinemachine_transposer.html#a9391fc6311fa649d3dc0ce8923f0c2fe", null ],
    [ "InitPrevFrameStateInfo", "class_cinemachine_1_1_cinemachine_transposer.html#a61cca055c8498f20ffcbdcc2355116bb", null ],
    [ "MutateCameraState", "class_cinemachine_1_1_cinemachine_transposer.html#ad422ba8f998aae4d18d331a9b8a92d9d", null ],
    [ "OnPositionDragged", "class_cinemachine_1_1_cinemachine_transposer.html#a3a1341e69e5e6451cdca0cc643e2787a", null ],
    [ "OnValidate", "class_cinemachine_1_1_cinemachine_transposer.html#a5e7a884c7a8bc539c5e076c4dbc4997d", null ],
    [ "TrackTarget", "class_cinemachine_1_1_cinemachine_transposer.html#af8c57829cda34cabaac9eaabdb2083c3", null ],
    [ "m_BindingMode", "class_cinemachine_1_1_cinemachine_transposer.html#afe6ee25d14af3182163e5dca02cbf2f9", null ],
    [ "m_FollowOffset", "class_cinemachine_1_1_cinemachine_transposer.html#a1a58793b74f4ce0a02d2f98c563826cc", null ],
    [ "m_PitchDamping", "class_cinemachine_1_1_cinemachine_transposer.html#a368fb49bc1db0c99695f2cfc82015a61", null ],
    [ "m_RollDamping", "class_cinemachine_1_1_cinemachine_transposer.html#a667c0325216485a2e7eba253267e5ef8", null ],
    [ "m_XDamping", "class_cinemachine_1_1_cinemachine_transposer.html#a4f9c70ae969ad67e776f6f895d4a2472", null ],
    [ "m_YawDamping", "class_cinemachine_1_1_cinemachine_transposer.html#ac3d909ddb452ee7786cc77b93d8b3559", null ],
    [ "m_YDamping", "class_cinemachine_1_1_cinemachine_transposer.html#a1df0959363ae63b5c153fa2e3b639a22", null ],
    [ "m_ZDamping", "class_cinemachine_1_1_cinemachine_transposer.html#a21309207da0eb4c8d194e684a7b07f31", null ],
    [ "AngularDamping", "class_cinemachine_1_1_cinemachine_transposer.html#a2a3a9cb6b3dcf22a61f456cfb2a32e8a", null ],
    [ "Damping", "class_cinemachine_1_1_cinemachine_transposer.html#aa51c6155af0bcb85ac5861ea235a97ca", null ],
    [ "EffectiveOffset", "class_cinemachine_1_1_cinemachine_transposer.html#ada43e86ff4ee8e630abb1de8d3441fdd", null ],
    [ "IsValid", "class_cinemachine_1_1_cinemachine_transposer.html#aea9cb7d40ab38d2acf22f9f9059147d8", null ],
    [ "Stage", "class_cinemachine_1_1_cinemachine_transposer.html#a3e05fc3508e8f16b1aee910ca195ec04", null ]
];