var class_cinemachine_1_1_utility_1_1_unity_rect_extensions =
[
    [ "Inflated", "class_cinemachine_1_1_utility_1_1_unity_rect_extensions.html#a60df9a4aaf353a9d52e0bdaa45a62a4d", null ]
];