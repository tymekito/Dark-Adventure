var class_c_f_x___demo___rotate_camera =
[
    [ "rotating", "class_c_f_x___demo___rotate_camera.html#a42f72529c7722e6ef17df8177b972fee", null ],
    [ "rotationCenter", "class_c_f_x___demo___rotate_camera.html#ade15634137d9b43fd3b2e16edb47d53f", null ],
    [ "speed", "class_c_f_x___demo___rotate_camera.html#a6b22f41ef87b135a99a88f5f0f6e8718", null ]
];