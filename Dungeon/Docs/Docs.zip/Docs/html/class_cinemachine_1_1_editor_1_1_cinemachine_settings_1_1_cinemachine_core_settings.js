var class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_cinemachine_core_settings =
[
    [ "kDefaultActiveColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_cinemachine_core_settings.html#a9e867391dad019642d31f87bb8dc61ff", null ],
    [ "kDefaultInactiveColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_cinemachine_core_settings.html#a86fb3d2aefda1c60f9ad9f3bd3a7b4c4", null ],
    [ "ActiveGizmoColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_cinemachine_core_settings.html#af0baad7895364f9bbd4f63d303d6b574", null ],
    [ "InactiveGizmoColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_cinemachine_core_settings.html#aff33afa0d77a64d3a8cce0d8adebbd49", null ],
    [ "ShowInGameGuides", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_cinemachine_core_settings.html#ae15cb13306e216d21e91b156a2820a21", null ]
];