var dir_627990de76f0c33795a51c56e9a2ea85 =
[
    [ "AxisState.cs", "_axis_state_8cs.html", [
      [ "AxisState", "struct_cinemachine_1_1_axis_state.html", "struct_cinemachine_1_1_axis_state" ]
    ] ],
    [ "CameraState.cs", "_camera_state_8cs.html", [
      [ "CameraState", "struct_cinemachine_1_1_camera_state.html", "struct_cinemachine_1_1_camera_state" ],
      [ "CustomBlendable", "struct_cinemachine_1_1_camera_state_1_1_custom_blendable.html", "struct_cinemachine_1_1_camera_state_1_1_custom_blendable" ]
    ] ],
    [ "CinemachineBlend.cs", "_cinemachine_blend_8cs.html", [
      [ "CinemachineBlend", "class_cinemachine_1_1_cinemachine_blend.html", "class_cinemachine_1_1_cinemachine_blend" ],
      [ "CinemachineBlendDefinition", "struct_cinemachine_1_1_cinemachine_blend_definition.html", "struct_cinemachine_1_1_cinemachine_blend_definition" ]
    ] ],
    [ "CinemachineBlenderSettings.cs", "_cinemachine_blender_settings_8cs.html", [
      [ "CinemachineBlenderSettings", "class_cinemachine_1_1_cinemachine_blender_settings.html", "class_cinemachine_1_1_cinemachine_blender_settings" ],
      [ "CustomBlend", "struct_cinemachine_1_1_cinemachine_blender_settings_1_1_custom_blend.html", "struct_cinemachine_1_1_cinemachine_blender_settings_1_1_custom_blend" ]
    ] ],
    [ "CinemachineComponentBase.cs", "_cinemachine_component_base_8cs.html", [
      [ "CinemachineComponentBase", "class_cinemachine_1_1_cinemachine_component_base.html", "class_cinemachine_1_1_cinemachine_component_base" ]
    ] ],
    [ "CinemachineCore.cs", "_cinemachine_core_8cs.html", [
      [ "CinemachineCore", "class_cinemachine_1_1_cinemachine_core.html", "class_cinemachine_1_1_cinemachine_core" ]
    ] ],
    [ "CinemachineDebugLogger.cs", "_cinemachine_debug_logger_8cs.html", [
      [ "CinemachineGameWindowDebug", "class_cinemachine_1_1_utility_1_1_cinemachine_game_window_debug.html", "class_cinemachine_1_1_utility_1_1_cinemachine_game_window_debug" ]
    ] ],
    [ "CinemachineExtension.cs", "_cinemachine_extension_8cs.html", [
      [ "CinemachineExtension", "class_cinemachine_1_1_cinemachine_extension.html", "class_cinemachine_1_1_cinemachine_extension" ]
    ] ],
    [ "CinemachinePathBase.cs", "_cinemachine_path_base_8cs.html", [
      [ "CinemachinePathBase", "class_cinemachine_1_1_cinemachine_path_base.html", "class_cinemachine_1_1_cinemachine_path_base" ],
      [ "Appearance", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance.html", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance" ]
    ] ],
    [ "CinemachinePropertyAttribute.cs", "_cinemachine_property_attribute_8cs.html", [
      [ "LensSettingsPropertyAttribute", "class_cinemachine_1_1_lens_settings_property_attribute.html", null ],
      [ "CinemachineBlendDefinitionPropertyAttribute", "class_cinemachine_1_1_cinemachine_blend_definition_property_attribute.html", null ],
      [ "SaveDuringPlayAttribute", "class_cinemachine_1_1_save_during_play_attribute.html", null ],
      [ "NoSaveDuringPlayAttribute", "class_cinemachine_1_1_no_save_during_play_attribute.html", null ],
      [ "TagFieldAttribute", "class_cinemachine_1_1_tag_field_attribute.html", null ],
      [ "DocumentationSortingAttribute", "class_cinemachine_1_1_documentation_sorting_attribute.html", "class_cinemachine_1_1_documentation_sorting_attribute" ]
    ] ],
    [ "CinemachineVirtualCameraBase.cs", "_cinemachine_virtual_camera_base_8cs.html", [
      [ "CinemachineVirtualCameraBase", "class_cinemachine_1_1_cinemachine_virtual_camera_base.html", "class_cinemachine_1_1_cinemachine_virtual_camera_base" ]
    ] ],
    [ "GaussianFilter.cs", "_gaussian_filter_8cs.html", null ],
    [ "ICinemachineCamera.cs", "_i_cinemachine_camera_8cs.html", [
      [ "ICinemachineCamera", "interface_cinemachine_1_1_i_cinemachine_camera.html", "interface_cinemachine_1_1_i_cinemachine_camera" ]
    ] ],
    [ "ICinemachineComponent.cs", "_i_cinemachine_component_8cs.html", null ],
    [ "LensSettings.cs", "_lens_settings_8cs.html", [
      [ "LensSettings", "struct_cinemachine_1_1_lens_settings.html", "struct_cinemachine_1_1_lens_settings" ]
    ] ],
    [ "NoiseSettings.cs", "_noise_settings_8cs.html", [
      [ "NoiseSettings", "class_cinemachine_1_1_noise_settings.html", "class_cinemachine_1_1_noise_settings" ],
      [ "NoiseParams", "struct_cinemachine_1_1_noise_settings_1_1_noise_params.html", "struct_cinemachine_1_1_noise_settings_1_1_noise_params" ],
      [ "TransformNoiseParams", "struct_cinemachine_1_1_noise_settings_1_1_transform_noise_params.html", "struct_cinemachine_1_1_noise_settings_1_1_transform_noise_params" ]
    ] ],
    [ "Predictor.cs", "_predictor_8cs.html", [
      [ "Damper", "class_cinemachine_1_1_utility_1_1_damper.html", "class_cinemachine_1_1_utility_1_1_damper" ]
    ] ],
    [ "ReflectionHelpers.cs", "_reflection_helpers_8cs.html", [
      [ "ReflectionHelpers", "class_cinemachine_1_1_utility_1_1_reflection_helpers.html", "class_cinemachine_1_1_utility_1_1_reflection_helpers" ]
    ] ],
    [ "SplineHelpers.cs", "_spline_helpers_8cs.html", null ],
    [ "UnityVectorExtensions.cs", "_unity_vector_extensions_8cs.html", [
      [ "UnityVectorExtensions", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions" ],
      [ "UnityQuaternionExtensions", "class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions.html", "class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions" ],
      [ "UnityRectExtensions", "class_cinemachine_1_1_utility_1_1_unity_rect_extensions.html", "class_cinemachine_1_1_utility_1_1_unity_rect_extensions" ]
    ] ]
];