var class_save_during_play_1_1_save_during_play =
[
    [ "OnHotSaveDelegate", "class_save_during_play_1_1_save_during_play.html#a4cfebeaf695118a950cadbb3f7305bc1", null ],
    [ "kEnabledKey", "class_save_during_play_1_1_save_during_play.html#a6bac85f9e1c6a693b6f57cd48ab3482b", null ],
    [ "OnHotSave", "class_save_during_play_1_1_save_during_play.html#ac1846a1fb9722e6926c171ebf9f32a95", null ],
    [ "Enabled", "class_save_during_play_1_1_save_during_play.html#a85fb0323297322eaed9fedd882985f93", null ]
];