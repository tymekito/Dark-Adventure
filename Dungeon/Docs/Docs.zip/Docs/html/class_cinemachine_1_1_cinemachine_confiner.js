var class_cinemachine_1_1_cinemachine_confiner =
[
    [ "Mode", "class_cinemachine_1_1_cinemachine_confiner.html#a8b3907c9a1b1ac296e0f9c28cc2ddfd8", [
      [ "Confine2D", "class_cinemachine_1_1_cinemachine_confiner.html#a8b3907c9a1b1ac296e0f9c28cc2ddfd8a9c70dc056290434823ebbf38e53f34fa", null ],
      [ "Confine3D", "class_cinemachine_1_1_cinemachine_confiner.html#a8b3907c9a1b1ac296e0f9c28cc2ddfd8a84ac289df3e8a501acb3962f274d938f", null ]
    ] ],
    [ "CameraWasDisplaced", "class_cinemachine_1_1_cinemachine_confiner.html#a0d585d5313cf676a86daa84a345f8bd6", null ],
    [ "InvalidatePathCache", "class_cinemachine_1_1_cinemachine_confiner.html#a2b3cc840d038253b62e12114aa3ad7d2", null ],
    [ "PostPipelineStageCallback", "class_cinemachine_1_1_cinemachine_confiner.html#ad2373a23f9677db8052f165988c3305a", null ],
    [ "m_BoundingShape2D", "class_cinemachine_1_1_cinemachine_confiner.html#a334ba008b6c8551395d06446c6c1081d", null ],
    [ "m_BoundingVolume", "class_cinemachine_1_1_cinemachine_confiner.html#a23a0b976deb919dc6542c730d0dde377", null ],
    [ "m_ConfineMode", "class_cinemachine_1_1_cinemachine_confiner.html#ac2ac5987d5a30a803235b54e9b89c722", null ],
    [ "m_ConfineScreenEdges", "class_cinemachine_1_1_cinemachine_confiner.html#a0f9906f404a32beb5ace19a7a25c04c3", null ],
    [ "m_Damping", "class_cinemachine_1_1_cinemachine_confiner.html#ad21342f5b043034921bf15ab76ec721e", null ],
    [ "IsValid", "class_cinemachine_1_1_cinemachine_confiner.html#a1eb45d13487992eb89868b806a54a878", null ]
];