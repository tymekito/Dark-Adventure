var class_back_to_menu =
[
    [ "Menu", "class_back_to_menu.html#a035e6d73fb5f4f33270beb59025b0b3e", null ]
];