var class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions =
[
    [ "ApplyCameraRotation", "class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions.html#ab7e5d9689bab0f366bf6422c894779d6", null ],
    [ "GetCameraRotationToTarget", "class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions.html#a483a96d29aaea2bb1b6e4563786dec79", null ],
    [ "Normalized", "class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions.html#aff8dead4a6cc9cf30bca3db2195af8b3", null ],
    [ "SlerpWithReferenceUp", "class_cinemachine_1_1_utility_1_1_unity_quaternion_extensions.html#a2a7dd315397d6576dffcde042b53238d", null ]
];