var class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings =
[
    [ "kDefaultHardBoundsColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#afe37a9d49a7e596e1bac688776c85cf1", null ],
    [ "kDefaultOverlayOpacity", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a446335210903ee052cc93d12f202fafb", null ],
    [ "kDefaultSoftBoundsColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a48a9e637ecfad7f7e68adcbf77b277a4", null ],
    [ "kDefaultTargetColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a7762d1721a76bb4fafa86e007e1c7b27", null ],
    [ "HardBoundsOverlayColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#af065a28d78179ab1fdb55711c08f159b", null ],
    [ "OverlayOpacity", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a5fff5ed9588125163f44671ef79948cd", null ],
    [ "SoftBoundsOverlayColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a47ded6c64c5f56ccfda4e0fba3ba200f", null ],
    [ "TargetColour", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a67ddc6a7d0b3a8b6bd082f3aae65a16f", null ],
    [ "TargetSize", "class_cinemachine_1_1_editor_1_1_cinemachine_settings_1_1_composer_settings.html#a96bc89fc7929c9951949b0d7816897ee", null ]
];