var class_cinemachine_1_1_documentation_sorting_attribute =
[
    [ "Level", "class_cinemachine_1_1_documentation_sorting_attribute.html#af908b9bac2aa13d719a425dfe2af107f", [
      [ "Undoc", "class_cinemachine_1_1_documentation_sorting_attribute.html#af908b9bac2aa13d719a425dfe2af107fad3142866fb76e7dc7d0ff04251bc57a0", null ],
      [ "API", "class_cinemachine_1_1_documentation_sorting_attribute.html#af908b9bac2aa13d719a425dfe2af107fadb974238714ca8de634a7ce1d083a14f", null ],
      [ "UserRef", "class_cinemachine_1_1_documentation_sorting_attribute.html#af908b9bac2aa13d719a425dfe2af107fa1fa30b10ca4a30e35f0be88982b33aa0", null ]
    ] ],
    [ "DocumentationSortingAttribute", "class_cinemachine_1_1_documentation_sorting_attribute.html#a14e19f159d819dd5fa7be8312a3d8aea", null ],
    [ "Category", "class_cinemachine_1_1_documentation_sorting_attribute.html#a258ec800c1d713be71ac6bf2b8195e68", null ],
    [ "SortOrder", "class_cinemachine_1_1_documentation_sorting_attribute.html#ac3e604eda2361b21124633926054d680", null ]
];