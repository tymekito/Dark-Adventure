var class_boss_room =
[
    [ "CloseDoors", "class_boss_room.html#a266f082766bb43afef2eef8916bb1620", null ],
    [ "OpenDoors", "class_boss_room.html#a9eb2734c82694b82c6a1c57475dc32e1", null ],
    [ "OpenSkull", "class_boss_room.html#a57d7205f4de598a7cbb6473299d4d00b", null ],
    [ "SpawnBoss", "class_boss_room.html#ad93e218570932403fbb1de934720fa36", null ],
    [ "ColissionAudio", "class_boss_room.html#a98e70b0294897ea38adeaa8196700997", null ],
    [ "WinSound", "class_boss_room.html#a3b66f0351495c2269c431742a7f202e2", null ]
];