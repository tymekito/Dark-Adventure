var class_permanent_u_i =
[
    [ "CreateBossHealthBar", "class_permanent_u_i.html#a1ba88221697481a07663d17536301473", null ],
    [ "DestroyBossHealthBar", "class_permanent_u_i.html#a186a3073509c6329fb4a0de7362d7a56", null ],
    [ "DestroyUI", "class_permanent_u_i.html#a26ef2bc760a59fb687c86c2b34e3eeff", null ],
    [ "LoadPlayerStats", "class_permanent_u_i.html#a688049b9f5f3892b0d0191198a6b56d8", null ],
    [ "Reset", "class_permanent_u_i.html#a1bc4cb973acce79c1cafdddfd475eaf7", null ],
    [ "SavePlayerStats", "class_permanent_u_i.html#ae003871e29e99767d81845625c97c2f2", null ],
    [ "greenKey", "class_permanent_u_i.html#a0069bb4adcffaa3ec1f8b0b4c2789e61", null ],
    [ "health", "class_permanent_u_i.html#aebbf407c3cbf91c405f3e9b53f84afbe", null ],
    [ "perm", "class_permanent_u_i.html#abbd06c477c23d6daafa5d5f8c0daf314", null ],
    [ "playerAtackSpeed", "class_permanent_u_i.html#acc4ef7ef6cbbc4a1f459780eb9934a88", null ],
    [ "playerDMG", "class_permanent_u_i.html#a2b820540c07b6dd01622a561f731c3d7", null ],
    [ "playerMovmentSpeed", "class_permanent_u_i.html#a0210bbac65eb4e84969a2cb82b704ae4", null ],
    [ "redKey", "class_permanent_u_i.html#aaf1039f3be6cd9873a6068a953efed79", null ],
    [ "score", "class_permanent_u_i.html#a93dca7c3b9c35e3c26491d7bbeb10048", null ],
    [ "scoreText", "class_permanent_u_i.html#ac858e53972b41ae076e21640c196df9c", null ]
];