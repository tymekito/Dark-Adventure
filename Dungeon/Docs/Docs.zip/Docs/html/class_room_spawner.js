var class_room_spawner =
[
    [ "waitTime", "class_room_spawner.html#a511544ab648419480ecd7e1ea287a6bf", null ]
];