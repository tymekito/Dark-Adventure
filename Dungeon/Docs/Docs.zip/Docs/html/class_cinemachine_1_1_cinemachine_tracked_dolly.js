var class_cinemachine_1_1_cinemachine_tracked_dolly =
[
    [ "AutoDolly", "struct_cinemachine_1_1_cinemachine_tracked_dolly_1_1_auto_dolly.html", "struct_cinemachine_1_1_cinemachine_tracked_dolly_1_1_auto_dolly" ],
    [ "CameraUpMode", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5314aa15b42b2053c324061aeb2f368b", [
      [ "Default", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5314aa15b42b2053c324061aeb2f368ba7a1920d61156abc05a60135aefe8bc67", null ],
      [ "Path", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5314aa15b42b2053c324061aeb2f368baac70412e939d72a9234cdebb1af5867b", null ],
      [ "PathNoRoll", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5314aa15b42b2053c324061aeb2f368ba9b46806748810ea10219eb49d8d3e7c6", null ],
      [ "FollowTarget", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5314aa15b42b2053c324061aeb2f368ba23a0d6103e6eb8265ec3203088db3c9c", null ],
      [ "FollowTargetNoRoll", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5314aa15b42b2053c324061aeb2f368ba47f4b6ba39b9ed9e4e42ee844b3d0663", null ]
    ] ],
    [ "MutateCameraState", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a6f50dcdaea1f4de2cc64f24502f559e4", null ],
    [ "OnPositionDragged", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a480bf07b9ee293806359049ed041b210", null ],
    [ "m_AutoDolly", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a756a4498629bd77b6dd328bc9dd826fe", null ],
    [ "m_CameraUp", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#ad57274d844b7ce168c6ac2b6ba175a21", null ],
    [ "m_Path", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a2005409e353b7274dfe783af04a008d6", null ],
    [ "m_PathOffset", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a92beb903b853fabaf01a5874f8def96a", null ],
    [ "m_PathPosition", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a784421a5b3adb4ce0661701bcb5650b7", null ],
    [ "m_PitchDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#ab38b2a9f39ffed59e731004e823618a2", null ],
    [ "m_PositionUnits", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a5aae28ee862fe200b55bf31ee7174b39", null ],
    [ "m_RollDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#ad5b4df15448d6a142764495e16ea4872", null ],
    [ "m_XDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a10a92734c9cc21bd6261f5937edda2a0", null ],
    [ "m_YawDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a236cc72a4a7411e4563723842f52bfee", null ],
    [ "m_YDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#ad44cbb50ade6afa6d9684b5fd29bf5c7", null ],
    [ "m_ZDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#aeca59dd97f085485751b5ac433609b85", null ],
    [ "AngularDamping", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a1285b96d104f92c53f1aeb88c7c9c8d7", null ],
    [ "IsValid", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a174667636410d1f196a8e508d8507d3f", null ],
    [ "Stage", "class_cinemachine_1_1_cinemachine_tracked_dolly.html#a226ee01c720a6c43c4593d3f05d1a945", null ]
];