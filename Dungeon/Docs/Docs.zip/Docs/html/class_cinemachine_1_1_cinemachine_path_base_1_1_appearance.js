var class_cinemachine_1_1_cinemachine_path_base_1_1_appearance =
[
    [ "inactivePathColor", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance.html#a9dbded3393036e5b5639e3552105fa45", null ],
    [ "pathColor", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance.html#afde399e4f72dc44e3476f1252838ca81", null ],
    [ "width", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance.html#aa51df2650323dbf9b5f9f5d53b54d5d6", null ]
];