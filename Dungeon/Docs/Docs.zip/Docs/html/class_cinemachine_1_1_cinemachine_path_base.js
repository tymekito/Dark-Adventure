var class_cinemachine_1_1_cinemachine_path_base =
[
    [ "Appearance", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance.html", "class_cinemachine_1_1_cinemachine_path_base_1_1_appearance" ],
    [ "PositionUnits", "class_cinemachine_1_1_cinemachine_path_base.html#ad3c407adc1855df3b0d912d61b69c69e", [
      [ "PathUnits", "class_cinemachine_1_1_cinemachine_path_base.html#ad3c407adc1855df3b0d912d61b69c69ea57b6e5dee6587ea54ef9ccc4050fee97", null ],
      [ "Distance", "class_cinemachine_1_1_cinemachine_path_base.html#ad3c407adc1855df3b0d912d61b69c69ea0aa6f4210bf373c95eda00232e93cd98", null ]
    ] ],
    [ "DistanceCacheIsValid", "class_cinemachine_1_1_cinemachine_path_base.html#af026661268a1b13370557022f24884bc", null ],
    [ "EvaluateOrientation", "class_cinemachine_1_1_cinemachine_path_base.html#a0d90a9d750ce5f2cb03a0f2a27900d82", null ],
    [ "EvaluateOrientationAtUnit", "class_cinemachine_1_1_cinemachine_path_base.html#ac97a5070d67f133a10044d1052aec4a4", null ],
    [ "EvaluatePosition", "class_cinemachine_1_1_cinemachine_path_base.html#a571b662054c52f5e08af88c1f6e01b19", null ],
    [ "EvaluatePositionAtUnit", "class_cinemachine_1_1_cinemachine_path_base.html#a1ea2ea848341f7a8fb0d62ca8457a5a0", null ],
    [ "EvaluateTangent", "class_cinemachine_1_1_cinemachine_path_base.html#ac000e4febde42d7da4ad5dd8aa3f1f54", null ],
    [ "EvaluateTangentAtUnit", "class_cinemachine_1_1_cinemachine_path_base.html#aa201e2e03736063f37e8202874d5d82e", null ],
    [ "FindClosestPoint", "class_cinemachine_1_1_cinemachine_path_base.html#ab674e5957b55cbe0329feb929277844f", null ],
    [ "GetPathDistanceFromPosition", "class_cinemachine_1_1_cinemachine_path_base.html#a313a071b8edad20717662638b21102d2", null ],
    [ "GetPathPositionFromDistance", "class_cinemachine_1_1_cinemachine_path_base.html#a9ed2168e2d4fd35b876819c65634d6f5", null ],
    [ "InvalidateDistanceCache", "class_cinemachine_1_1_cinemachine_path_base.html#a137dfb8aa6b4f0162d6eb7a09f7cc17c", null ],
    [ "MaxUnit", "class_cinemachine_1_1_cinemachine_path_base.html#a178e688ee877c258a43574370b852e8b", null ],
    [ "MinUnit", "class_cinemachine_1_1_cinemachine_path_base.html#aabd1581473d62acf2113d34e6bb26884", null ],
    [ "NormalizePathDistance", "class_cinemachine_1_1_cinemachine_path_base.html#aa5fd6b5cd6c1840283e9b80fd78e9338", null ],
    [ "NormalizePos", "class_cinemachine_1_1_cinemachine_path_base.html#aa949c956a2a3053b4d901e9d4f918623", null ],
    [ "NormalizeUnit", "class_cinemachine_1_1_cinemachine_path_base.html#a9999866b540e2ba721573af13b178917", null ],
    [ "m_Appearance", "class_cinemachine_1_1_cinemachine_path_base.html#aabfcb42c5a6971de486bb99c05518c0f", null ],
    [ "m_Resolution", "class_cinemachine_1_1_cinemachine_path_base.html#a87d542bfbdf4d802ac2326ce75f2229c", null ],
    [ "DistanceCacheSampleStepsPerSegment", "class_cinemachine_1_1_cinemachine_path_base.html#a0a54e2d63a57e9c7df8db2e3c971d685", null ],
    [ "Looped", "class_cinemachine_1_1_cinemachine_path_base.html#a2e8e52f07cd8c2b2e152d3ca0c07d938", null ],
    [ "MaxPos", "class_cinemachine_1_1_cinemachine_path_base.html#a7a4c157dbf4fa8ea805dbfe6cff0da3a", null ],
    [ "MinPos", "class_cinemachine_1_1_cinemachine_path_base.html#ae93d650553246fe7cf6e9492bc5e8f1c", null ],
    [ "PathLength", "class_cinemachine_1_1_cinemachine_path_base.html#a66c7835ad33d6d7e6a8bd20816945919", null ]
];