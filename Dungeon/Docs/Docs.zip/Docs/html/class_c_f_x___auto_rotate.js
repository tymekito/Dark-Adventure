var class_c_f_x___auto_rotate =
[
    [ "rotation", "class_c_f_x___auto_rotate.html#a56dd1db0b6edf60eda5c3eb92faa43b2", null ],
    [ "space", "class_c_f_x___auto_rotate.html#aa615b897c53b6d4e4be05fa56053edf3", null ]
];