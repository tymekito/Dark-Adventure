var class_cinemachine_1_1_editor_1_1_cinemachine_collider_editor =
[
    [ "GetExcludedPropertiesInInspector", "class_cinemachine_1_1_editor_1_1_cinemachine_collider_editor.html#a6100529790e9b9269d0bb13da8ba8e52", null ],
    [ "OnInspectorGUI", "class_cinemachine_1_1_editor_1_1_cinemachine_collider_editor.html#a7fffad8cd59adad41eb3c91f9462fedc", null ]
];