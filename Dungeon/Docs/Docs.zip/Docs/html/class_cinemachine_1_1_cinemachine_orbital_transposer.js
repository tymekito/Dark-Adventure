var class_cinemachine_1_1_cinemachine_orbital_transposer =
[
    [ "Heading", "struct_cinemachine_1_1_cinemachine_orbital_transposer_1_1_heading.html", "struct_cinemachine_1_1_cinemachine_orbital_transposer_1_1_heading" ],
    [ "Recentering", "struct_cinemachine_1_1_cinemachine_orbital_transposer_1_1_recentering.html", "struct_cinemachine_1_1_cinemachine_orbital_transposer_1_1_recentering" ],
    [ "MutateCameraState", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a09cc55b60f2ac9552e178e8f02d80dd7", null ],
    [ "OnPositionDragged", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a1949baae43ced226dab896a8b5d73ed9", null ],
    [ "OnValidate", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a7d762f4536124cee6e22266557294289", null ],
    [ "UpdateHeading", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a555ee6081cde736a6c0997a79fafe221", null ],
    [ "m_Heading", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a7a0195773811a12bbccf2e72330dc4bd", null ],
    [ "m_HeadingIsSlave", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#aa065c2be5544863d73940ff40f1fc7bd", null ],
    [ "m_RecenterToTargetHeading", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a233e18ad8b8afadae030d0d2c5103499", null ],
    [ "m_XAxis", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#aec8b0fb8042359a8500e19697390de5c", null ],
    [ "PreviousTarget", "class_cinemachine_1_1_cinemachine_orbital_transposer.html#a43b7154f1fa9e2af37fb8a42c2bef9ec", null ]
];