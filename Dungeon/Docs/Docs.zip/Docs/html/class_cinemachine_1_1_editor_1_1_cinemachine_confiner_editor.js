var class_cinemachine_1_1_editor_1_1_cinemachine_confiner_editor =
[
    [ "GetExcludedPropertiesInInspector", "class_cinemachine_1_1_editor_1_1_cinemachine_confiner_editor.html#a6fa3e4b5c09cbc68207148d33f04484d", null ],
    [ "OnInspectorGUI", "class_cinemachine_1_1_editor_1_1_cinemachine_confiner_editor.html#ae2d147c7fc506f23e6e12865af2ec8f4", null ]
];