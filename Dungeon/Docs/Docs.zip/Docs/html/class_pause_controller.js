var class_pause_controller =
[
    [ "menuReturn", "class_pause_controller.html#ab93e05f905affe6abe13077199ab4270", null ],
    [ "pauseGame", "class_pause_controller.html#a15b7fba73e55f1865cdbfd35c67cecfa", null ],
    [ "resumeGame", "class_pause_controller.html#a569f30364695021ecd603ce77063d334", null ]
];