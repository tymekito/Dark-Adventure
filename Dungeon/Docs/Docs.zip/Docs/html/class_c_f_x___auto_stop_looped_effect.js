var class_c_f_x___auto_stop_looped_effect =
[
    [ "effectDuration", "class_c_f_x___auto_stop_looped_effect.html#a365951dd07d458a7521e42e9ad7b2d11", null ]
];