var class_cinemachine_1_1_cinemachine_brain =
[
    [ "BrainEvent", "class_cinemachine_1_1_cinemachine_brain_1_1_brain_event.html", null ],
    [ "VcamEvent", "class_cinemachine_1_1_cinemachine_brain_1_1_vcam_event.html", null ],
    [ "UpdateMethod", "class_cinemachine_1_1_cinemachine_brain.html#ab60f93047b98695f698bb5888c87c21e", [
      [ "FixedUpdate", "class_cinemachine_1_1_cinemachine_brain.html#ab60f93047b98695f698bb5888c87c21ea9c1ca4069e206318b33ef896d3dd204e", null ],
      [ "LateUpdate", "class_cinemachine_1_1_cinemachine_brain.html#ab60f93047b98695f698bb5888c87c21ea2609005edfde618c70f2140bb3e9b7c2", null ],
      [ "SmartUpdate", "class_cinemachine_1_1_cinemachine_brain.html#ab60f93047b98695f698bb5888c87c21eac98c17243e0acc4a32b53a16b93ab203", null ]
    ] ],
    [ "GetSoloGUIColor", "class_cinemachine_1_1_cinemachine_brain.html#a59f850e807cf183e1e3d66b55dc511a5", null ],
    [ "IsLive", "class_cinemachine_1_1_cinemachine_brain.html#abde080e6d054b410287842f6c0471d07", null ],
    [ "m_CameraActivatedEvent", "class_cinemachine_1_1_cinemachine_brain.html#a6ec414d90f1fe7c931053e4e28e7b660", null ],
    [ "m_CameraCutEvent", "class_cinemachine_1_1_cinemachine_brain.html#ad83c8d1b67d3b8618c3200e755886636", null ],
    [ "m_CustomBlends", "class_cinemachine_1_1_cinemachine_brain.html#a1f05203079a5f7f59199c4905b0a5f98", null ],
    [ "m_DefaultBlend", "class_cinemachine_1_1_cinemachine_brain.html#a639284347ec97b20a388719a75b72516", null ],
    [ "m_IgnoreTimeScale", "class_cinemachine_1_1_cinemachine_brain.html#a72552f0702dc87b23abc97ef22b08c56", null ],
    [ "m_ShowCameraFrustum", "class_cinemachine_1_1_cinemachine_brain.html#ab3c7e6e2c90623b897ee6dd2c0e4e161", null ],
    [ "m_ShowDebugText", "class_cinemachine_1_1_cinemachine_brain.html#ac258dc16be8ed83ee65338932d6df9cb", null ],
    [ "m_UpdateMethod", "class_cinemachine_1_1_cinemachine_brain.html#a928b039aba284e7698f6eccaefa69ad8", null ],
    [ "m_WorldUpOverride", "class_cinemachine_1_1_cinemachine_brain.html#a01cf1e1fa34d6ed7dc813e56ed181fbb", null ],
    [ "ActiveBlend", "class_cinemachine_1_1_cinemachine_brain.html#a4f29710361ce8d19e16eadf4fe1f73ed", null ],
    [ "ActiveVirtualCamera", "class_cinemachine_1_1_cinemachine_brain.html#a3c5ae17d9869650f2671ae92035ae422", null ],
    [ "CurrentCameraState", "class_cinemachine_1_1_cinemachine_brain.html#ae06a80f2ed28e784ed06d4991e2c9556", null ],
    [ "DefaultWorldUp", "class_cinemachine_1_1_cinemachine_brain.html#a9158ee7f924744163303e8ca45df78d6", null ],
    [ "IsBlending", "class_cinemachine_1_1_cinemachine_brain.html#a883250175a20e00b3c6c1433e4332a10", null ],
    [ "OutputCamera", "class_cinemachine_1_1_cinemachine_brain.html#abec877430b34fdc903c6a8057ec76e02", null ],
    [ "PostProcessingComponent", "class_cinemachine_1_1_cinemachine_brain.html#a135eb39f0e3eae684ece987f20cc88ea", null ],
    [ "SoloCamera", "class_cinemachine_1_1_cinemachine_brain.html#ab7596fbe511d791f623587f176387af8", null ]
];