var class_c_f_x___demo___translate =
[
    [ "axis", "class_c_f_x___demo___translate.html#a5508c41c85a44e0c708f14401c6205f9", null ],
    [ "gravity", "class_c_f_x___demo___translate.html#a6905f0cdcd977129af2dc26ba1d69cf0", null ],
    [ "rotation", "class_c_f_x___demo___translate.html#ad21edddd8d923cf379e118bf3614f7d8", null ],
    [ "speed", "class_c_f_x___demo___translate.html#a82cbe70d7263e031856e2e30897a4689", null ]
];