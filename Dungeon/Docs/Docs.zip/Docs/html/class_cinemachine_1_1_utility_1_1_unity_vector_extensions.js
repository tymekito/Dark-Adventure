var class_cinemachine_1_1_utility_1_1_unity_vector_extensions =
[
    [ "AlmostZero", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#a385e1ae8d9ea5aefc3cacf7901ed6164", null ],
    [ "ClosestPointOnSegment", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#aaa1b8fce86c02e8faeb3aa916915a73b", null ],
    [ "ClosestPointOnSegment", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#a2628f4f358a8f77b4d81eec61df28c9f", null ],
    [ "ProjectOntoPlane", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#a267c00aa8405482583088009fcc8484b", null ],
    [ "SignedAngle", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#a17b4863198c5f1e8b2c970a8319a183c", null ],
    [ "SlerpWithReferenceUp", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#a506232c8f3a800897cc3bace14c484a6", null ],
    [ "Epsilon", "class_cinemachine_1_1_utility_1_1_unity_vector_extensions.html#ad0d4823bc94175d65432a41f74fdaf6f", null ]
];