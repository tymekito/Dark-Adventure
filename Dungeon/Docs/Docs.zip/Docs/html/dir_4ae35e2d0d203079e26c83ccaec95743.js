var dir_4ae35e2d0d203079e26c83ccaec95743 =
[
    [ "BackToMenu.cs", "_back_to_menu_8cs.html", [
      [ "BackToMenu", "class_back_to_menu.html", "class_back_to_menu" ]
    ] ],
    [ "ColsingCreditsController.cs", "_colsing_credits_controller_8cs.html", [
      [ "ColsingCreditsController", "class_colsing_credits_controller.html", "class_colsing_credits_controller" ]
    ] ],
    [ "HealthsController.cs", "_healths_controller_8cs.html", [
      [ "HealthsController", "class_healths_controller.html", null ]
    ] ],
    [ "Minmap.cs", "_minmap_8cs.html", [
      [ "Minmap", "class_minmap.html", null ]
    ] ],
    [ "PauseController.cs", "_pause_controller_8cs.html", [
      [ "PauseController", "class_pause_controller.html", "class_pause_controller" ]
    ] ],
    [ "PermanentUI.cs", "_permanent_u_i_8cs.html", [
      [ "PermanentUI", "class_permanent_u_i.html", "class_permanent_u_i" ]
    ] ]
];