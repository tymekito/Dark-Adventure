var class_player =
[
    [ "Attacked", "class_player.html#a1a30e36dfbad0358a4b19e1d70129e1e", null ],
    [ "EndHurtAnim", "class_player.html#a72aef087168a39e54e3832aad7f8d461", null ],
    [ "Heal", "class_player.html#aa2a6b0b0fc8987bbcb5f5b14c915bfe3", null ],
    [ "IsDead", "class_player.html#a736dc3ce9ee1c57f878475bd677a4985", null ],
    [ "Move", "class_player.html#a3fdebad803b97f4643696b3421be2195", null ],
    [ "UpgradeSpeed", "class_player.html#ac3a61155827e3cd45f93fc3c82e33133", null ],
    [ "loseSound", "class_player.html#acb31d8d3aecb817f1cd913a547827f8a", null ],
    [ "speed", "class_player.html#abd2291a934964b32e9bc06a7738042d3", null ]
];